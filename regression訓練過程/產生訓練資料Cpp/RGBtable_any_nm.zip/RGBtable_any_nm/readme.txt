os :
ubuntu 18.04.5

Compile instruction :
g++ -O2 Source_v2.cpp -o Source_v2 -fopenmp `pkg-config --cflags --libs opencv` -lopenblas

run :
./Source


